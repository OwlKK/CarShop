package com.capgemini.carshop.orders;

public interface Sender {

    void sendMessage();
}
