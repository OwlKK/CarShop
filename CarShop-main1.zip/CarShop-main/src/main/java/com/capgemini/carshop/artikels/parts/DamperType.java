package com.capgemini.carshop.artikels.parts;

public enum DamperType {
    Guillotine, Louver, Inlet_Vane, Blade, Butterfly_Flat_Dish
}
