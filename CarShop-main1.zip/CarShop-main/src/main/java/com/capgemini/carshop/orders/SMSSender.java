package com.capgemini.carshop.orders;

public class SMSSender implements Sender{

    public void sendMessage() {
        System.out.println("This is an SMS with purchase confirmation");
    }
}
