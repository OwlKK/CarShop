package com.capgemini.carshop.orders;

public class Customer { //TODO mozemy zrobic ID kazdemu customerowi

}
