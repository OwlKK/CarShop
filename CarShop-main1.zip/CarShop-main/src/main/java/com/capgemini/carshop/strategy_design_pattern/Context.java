package com.capgemini.carshop.strategy_design_pattern;

import com.capgemini.carshop.artikels.AbstractArticle;
import com.capgemini.carshop.strategy_design_pattern.optionsToGetUniqueList.*;


import java.util.List;
import java.util.Scanner;

public class Context {

    public static List<AbstractArticle> chooseAlgoAndGetUniqueList(List<AbstractArticle> articles) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Choose which algorithm do You want to use to create list of Unique Parts");
        String s = scanner.nextLine();
        switch (s) {
            case "Collection":
                return new Collection().getUniqueParts(articles);
            case "Frequency":
             return new Frequency().getUniqueParts(articles);
            case "Iteration":
          return new Iteration().getUniqueParts(articles);
            case "Map":
                return new Map().getUniqueParts(articles);
            case "Stream":
                return new Stream().getUniqueParts(articles);
            default:
                System.out.println("You did not choose anything");
        }
        return null;
    }
}
