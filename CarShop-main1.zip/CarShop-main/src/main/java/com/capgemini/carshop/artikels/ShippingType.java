package com.capgemini.carshop.artikels;

public enum ShippingType {

    Parcel_Machine, Post, To_Doors
}
