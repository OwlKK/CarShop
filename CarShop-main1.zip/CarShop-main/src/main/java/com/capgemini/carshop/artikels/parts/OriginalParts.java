package com.capgemini.carshop.artikels.parts;

public interface OriginalParts {

    public static final int ORIGINAL_DAMPER_DIESEL = 1234;
    public static final int ORIGINAL_FUEL_FILTER = 3456;
    public static final int ORIGINAL_SPRING = 4567;
}
