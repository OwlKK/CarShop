package com.capgemini.carshop.artikels.parts;


public interface Interchangeable {
    boolean isCompatible(Part p);
}
