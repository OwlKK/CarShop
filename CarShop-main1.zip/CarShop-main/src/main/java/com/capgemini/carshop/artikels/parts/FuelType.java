package com.capgemini.carshop.artikels.parts;

public enum FuelType {
    Gasoline, Diesel_Fuel, Bio_diesel, Ethanol
}
