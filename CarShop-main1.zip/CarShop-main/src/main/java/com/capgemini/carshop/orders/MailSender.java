package com.capgemini.carshop.orders;


public class MailSender implements Sender {

    public void sendMessage() {
        System.out.println("This is a mail with purchase confirmation"); //XD
    }
}
